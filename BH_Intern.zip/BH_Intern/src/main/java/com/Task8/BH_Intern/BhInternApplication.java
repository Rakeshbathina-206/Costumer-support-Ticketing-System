package com.Task8.BH_Intern;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BhInternApplication {

	public static void main(String[] args) {
		SpringApplication.run(BhInternApplication.class, args);
	}

}
