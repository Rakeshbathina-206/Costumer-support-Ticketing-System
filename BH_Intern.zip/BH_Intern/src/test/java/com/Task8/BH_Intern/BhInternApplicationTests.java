package com.Task8.BH_Intern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BhInternApplicationTests {

	@Test
	void contextLoads() {
	}

}
